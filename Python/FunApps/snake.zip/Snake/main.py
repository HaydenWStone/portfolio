import turtle
import time
from snake import Snake
from food import Food
from scoreboard import Scoreboard

#Config screen
screen = turtle.Screen()
screen.setup(width=600,height=600)
screen.bgcolor("black")
screen.title("SNAKE")
screen.tracer(0)

#Create primary game objects
snake = Snake()
food = Food()
score = 0
scoreboard = Scoreboard(score)
scoreboard.readysetgo()

#Start keystroke listening
screen.listen()
screen.onkey(snake.up,"Up")
screen.onkey(snake.down,"Down")
screen.onkey(snake.left,"Left")
screen.onkey(snake.right,"Right")

#Primary game functionality
game_on = True
while game_on:

    #Snake mover
    screen.update()
    time.sleep(.1)
    snake.move()

    #Detect when snake gets food
    if snake.head.distance(food) < 25:
        score += 1
        snake.extend()
        food.refresh()
        scoreboard.refresh(score)

    #Detect when snake hits right wall
    if snake.head.xcor() >= 300:
        scoreboard.gameover(score)
        game_on = False

    #Detect when snake hits left wall
    if snake.head.xcor() <= -300:
        scoreboard.gameover(score)
        game_on = False

    #Detect when snake hits top wall
    if snake.head.ycor() >= 300:
        scoreboard.gameover(score)
        game_on = False

    #Detect when snake hits bottom wall
    if snake.head.ycor() <= -300:
        scoreboard.gameover(score)
        game_on = False

    #Detect when snake hits its own tail
    for segment in snake.segments[1:(len(snake.segments)+1)]:
        if snake.head.distance(segment) < 10:
            scoreboard.gameover(score)
            game_on = False

screen.exitonclick()