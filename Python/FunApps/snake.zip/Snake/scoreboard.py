import turtle
import time

class Scoreboard(turtle.Turtle):
    #Initialize scoreboard
    def __init__(self,score):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.goto(0, 250)
        self.color("white")

    #Increase score
    def refresh(self,score):
        high_score_file = open("high_score.txt")
        high_score = int(high_score_file.read())
        high_score_file.close()
        self.goto(0, 250)
        self.clear()
        self.write(f"Score: {score}  High Score: {high_score}", move=False, align='center', font=('Arial', 14, 'bold'))

    #Write GAME OVER message
    def gameover(self,score):
        self.goto(0, 0)
        self.write("GAME OVER", move=False, align='center', font=('Arial', 14, 'bold'))
        high_score_file = open("high_score.txt",mode="r")
        high_score = int(high_score_file.read())
        high_score_file.close()
        if score > high_score:
            high_score_file = open("high_score.txt", mode="w")
            high_score_file.write(str(score))
            high_score_file.close()

    def readysetgo(self):
        self.goto(0, 0)
        self.write("READY", move=False, align='center', font=('Arial', 14, 'bold'))
        time.sleep(1)
        self.clear()
        self.write("SET", move=False, align='center', font=('Arial', 14, 'bold'))
        time.sleep(1)
        self.clear()
        self.write("GO", move=False, align='center', font=('Arial', 14, 'bold'))
        time.sleep(1)
        self.clear()



