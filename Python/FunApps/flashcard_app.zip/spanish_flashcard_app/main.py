"""
This script creates a simple flashcard program using tkinter
The default uses a list of the 500 most common Spanish words but any other language may be used
Progress is saved between uses
"""

import tkinter
import pandas
import random
import os

#Set starting vars
foreign_word = ""
english_word = ""
language = ""
BACKGROUND_COLOR = "#B1DDC6"

#Get word list
if os.path.isfile('words_to_learn.csv'):
    words = pandas.read_csv("words_to_learn.csv")
else:
    words = pandas.read_csv("500_es.csv")

#Select a word pair and display on card
def word_pick():
    global foreign_word
    global english_word
    global language
    word_pair = words.iloc[random.randint(0,len(words))]
    foreign_word = word_pair[0]
    english_word = word_pair[1]
    language = "Spanish"
    canvas.itemconfig(canvas_image,image=card_front)
    canvas.itemconfig(top_text,text=language,fill="black",font=("arial",40,"italic"))
    canvas.itemconfig(bottom_text, text=foreign_word,fill="black",font=("arial",60,"bold"))

#Cycle flipping card
def flip_card():
    # check if the canvas image is the front or back of the card
    if canvas.itemcget(canvas_image, "image") == str(card_front):
        # show the back of the card
        canvas.itemconfig(canvas_image, image=card_back)
        canvas.itemconfig(top_text, text="English")
        canvas.itemconfig(bottom_text, text=english_word)
    else:
        # show the front of the card
        canvas.itemconfig(canvas_image, image=card_front)
        canvas.itemconfig(top_text, text="Spanish")
        canvas.itemconfig(bottom_text, text=foreign_word)
    window.after_cancel(go_flip)
    window.after(3000, flip_card)

#Delete word from study list
def remove_word():
    global foreign_word
    global english_word
    global words
    words = words[words['Spanish'] != foreign_word]

    #Save progress
    words.to_csv('words_to_learn.csv', index=False)
    print(len(words))

    #Pick next word
    word_pick()

#Create main window
window = tkinter.Tk()
window.title("Flash Cards")
window.config(padx=50,pady=50,bg=BACKGROUND_COLOR)

#Red Button
wrong_image = tkinter.PhotoImage(file="wrong.png")
red = tkinter.Button(image=wrong_image,highlightthickness=0,command=word_pick)
red.grid(row=2,column=1)

#Green Button
right_image = tkinter.PhotoImage(file="right.png")
green = tkinter.Button(image=right_image,highlightthickness=0,command=remove_word)
green.grid(row=2,column=2)

#Flash Card Canvas
card_front = tkinter.PhotoImage(file="card_front.png")
card_back = tkinter.PhotoImage(file="card_back.png")
canvas = tkinter.Canvas(width=800,height=526,highlightthickness=0,bg=BACKGROUND_COLOR)
canvas_image = canvas.create_image(400,263,image=card_front)
top_text = canvas.create_text(400,150,text=language,fill="black",font=("arial",40,"italic"))
bottom_text = canvas.create_text(400,263,text=foreign_word,fill="black",font=("arial",60,"bold"))
canvas.grid(row=1,column=1,columnspan=2)

#Start program
go_flip = window.after(3000,flip_card)
word_pick()

#Main Loop
window.mainloop()